use pesquisa;

select * from pessoa;

-- contar quantos registros possui na tabela pessoa
select count(1) from pessoa;

select * from animal_estimacao;

-- contar quantos registros possui na tabela animal estimacao
select count(1) from animal_estimacao;

select * from bebida;

select * from hobbie;

select * from clima;

select * from stg_pesquisa;

select stg.data_coleta as data_pesquisa,
                           stg.cod_pessoa,
                           aes.cod_animal_estimacao,
                           beb.cod_bebida,
                           hob.cod_hobbie,
                           cli.cod_clima
                        from stg_pesquisa as stg
                            join animal_estimacao aes
                                on stg.animal_estimacao = aes.animal
                            join bebida as beb
                        on beb.bebida = bebida_favorita
                            join hobbie as hob
                                on hobbie = stg.hobbies
                            join clima as cli
                                on cli.clima = stg.clima