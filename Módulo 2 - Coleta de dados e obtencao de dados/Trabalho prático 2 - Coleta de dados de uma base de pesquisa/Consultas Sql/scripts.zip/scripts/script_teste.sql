use pesquisa;

select * from pesquisa;

-- Quantas pessoas do genero masculino gostam de peixe?
select genero, count(animal_estimacao)
	from stg_pesquisa where animal_estimacao = 'peixe'
    group by genero;
    
-- 1. Quantas pessoas do genero masculino gostam de peixe?
select genero, count(animal_estimacao)
	from stg_pesquisa 
    where animal_estimacao = 'peixe'
    and genero = 'Masculino'
    group by genero;




-- 3. Qual o hobbie de menor preferência entre as mulheres?
select genero, hobbies, count(hobbies) 
from stg_pesquisa
where genero = 'Feminino'
group by hobbies;

-- 4. Qual o hobbie de maior preferência entre as mulheres que gostam de  cachorro?
select genero, hobbies, count(hobbies) 
from stg_pesquisa
where genero = 'Feminino'
and animal_estimacao = 'cachorro'
group by hobbies;

-- 5. Qual a bebida favorita entre os mulheres e homens? respectivamente?

select genero, bebida_favorita, count(1) as total
from stg_pesquisa
where genero = 'Feminino'
group by genero, bebida_favorita
order by total desc;

select genero, bebida_favorita, count(1) as total
from stg_pesquisa
where genero = 'Masculino'
group by genero, bebida_favorita
order by total desc;    

-- 6. Qual é a média de idade das pessoas que tem como hobbie assistir TV?

-- hobbie, pessoa, idade
select hobbies, avg(idade)
from stg_pesquisa p
join idade ida 
on p.cod_pessoa = ida.cod_pessoa
where hobbies = 'Assistir TV'
group by hobbies;


-- 9. Quantas pessoas de modo geral gostam de cachorro?
select animal_estimacao, count(1)
from stg_pesquisa
where animal_estimacao = 'cachorro';

select genero, count(animal_estimacao)
	from stg_pesquisa 
    where animal_estimacao = 'cachorro'
    group by genero;
    
    
-- Qual a média de idade dos mulheres que gostam de chá e clima frio?
create temporary table idade
select 
    genero,
    data_nascimento,
    timestampdiff(year, stg.data_nascimento, now()) as idade
    from stg_pesquisa stg;

select genero, avg(idade)
	from idade
    group by genero;
  
-- contando bebida
select pes.genero, bbd.cod_bebida, bbd.bebida, count(1) as total
  from pesquisa pq 
       join bebida bbd on (pq.cod_bebida = bbd.cod_bebida)
       join pessoa pes on (pes.cod_pessoa = pq.cod_pessoa)
 group by pes.genero, bbd.cod_bebida
 order by total desc;
 
 -- por genero

 select pes.genero, bbd.cod_bebida, bbd.bebida, count(1) as total
  from pesquisa pq
       join bebida bbd on (pq.cod_bebida = bbd.cod_bebida)
       join pessoa pes on (pes.cod_pessoa = pq.cod_pessoa)
 where pes.genero = 'Feminino'
 group by pes.genero, bbd.cod_bebida
 order by total desc;
 
  select pes.genero, bbd.cod_bebida, bbd.bebida, count(1) as total
  from pesquisa pq
       join bebida bbd on (pq.cod_bebida = bbd.cod_bebida)
       join pessoa pes on (pes.cod_pessoa = pq.cod_pessoa)
 where pes.genero = 'Masculino'
 group by pes.genero, bbd.cod_bebida
 order by total desc;
 
select genero, bebida_favorita, count(1) as total
from stg_pesquisa
where genero = 'Masculino'
 group by genero, bebida_favorita
 order by total desc;
 
-- Qual é a média de idade das pessoas que tem como hobbie assistir TV? 45,92
select avg(idade)
from pesquisa pq
join hobbie hb
on pq.cod_hobbie = hb.hobbie
join pessoa pes
inner join idade ida
on ida.cod_pessoa = pes.cod_pessoa
where hb.hobbie = 'Assistir TV';

select *
from pessoa pes
	inner join idade ida on ida.cod_pessoa = pes.cod_pessoa;


-- Qual é a média de idade das pessoas que tem como hobbie assistir TV
select p.cod_pessoa, avg(idade)
from pesquisa p
join hobbie hb
on p.cod_hobbie = hb.hobbie
join pessoa pes
inner join idade ida
on ida.cod_pessoa = pes.cod_pessoa
where hb.hobbie = 'Assistir TV'
;


select ae.animal, count(1) total
from pesquisa p 
inner join animal_estimacao ae 
on p.cod_animal_estimacao = ae.cod_animal_estimacao 
where ae.animal = 'cachorro'
group by animal;

select pes.genero, bbd.cod_bebida, bbd.bebida, count(1) as total
  from pesquisa pq
       join bebida bbd on (pq.cod_bebida = bbd.cod_bebida)
       join pessoa pes on (pes.cod_pessoa = pq.cod_pessoa)
 group by pes.genero, bbd.cod_bebida
 order by total desc;